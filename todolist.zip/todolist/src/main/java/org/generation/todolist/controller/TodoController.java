package org.generation.todolist.controller;

import org.generation.todolist.entity.Todo;
import org.generation.todolist.repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TodoController {

    // Autowiring TodoRepository instance
    @Autowired
    private TodoRepository todoRepository;

    // Method to handle GET request to the home page
    @GetMapping("/")
    public String showTodoList(Model model) {
        Iterable<Todo> todoList = todoRepository.findAll();
        model.addAttribute("todos", todoList);
        return "todo-list";
    }

    // Method to handle GET request to show the add-todo form
    @GetMapping("/add-todo")
    public String showAddTodoForm(Model model) {
        model.addAttribute("todo", new Todo());
        return "add-todo";
    }

    // Method to handle POST request to add a new todo
    @PostMapping("/add-todo")
    public String addTodo(@ModelAttribute("todo") Todo todo) {
        todoRepository.save(todo);
        return "redirect:/";
    }

}

