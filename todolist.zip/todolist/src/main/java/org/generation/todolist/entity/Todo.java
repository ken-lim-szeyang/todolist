package org.generation.todolist.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity //annotate this class as a JPA entity
public class Todo {

    @Id // mark the id field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // configure id to be automatically generated
    private Long id;
    private String title;
    private String description;
    private String deadline;

    // Getter and Setter methods for the 3 fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

}

